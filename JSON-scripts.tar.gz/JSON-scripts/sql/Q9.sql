-- QUERY 9:
select myrecord -> 'first_name' as "first name",
       myrecord -> 'last_name' as "last name",
       myrecord -> 'street_address' as "street address",
       myrecord -> 'city' as "city",
       myrecord -> 'zip' as "zip"
from document;


 first name | last name |      street address      |     city     |   zip
------------+-----------+--------------------------+--------------+---------
 "robert"   | "bernier" | "123 my address"         | "my city"    | "12345"
 "conrad"   | "black"   | "1313 mocking bird lane" | "smallville" | "23451"
