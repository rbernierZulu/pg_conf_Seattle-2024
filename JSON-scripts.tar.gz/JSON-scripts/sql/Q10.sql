-- QUERY 10:
select myrecord -> 'first_name' as "first name",
       myrecord -> 'last_name' as "last name",
       myrecord -> 'street_address' as "street address",
       myrecord -> 'city' as "city",
       myrecord -> 'zip' as "zip"
from document
where
    myrecord ->> 'first_name' = 'conrad'
and myrecord ->> 'last_name' = 'black';

 first name | last name |      street address      |     city     |   zip
------------+-----------+--------------------------+--------------+---------
 "conrad"   | "black"   | "1313 mocking bird lane" | "smallville" | "23451"

