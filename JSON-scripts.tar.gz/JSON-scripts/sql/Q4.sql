-- QUERY 4:
select myrecord -> 'username_password' as "username/passswords" from document limit 1;
--------------------------------------------------------
[{"robert.bernier": "$1$AKXaaSQM$0029cNu0PHb/7UdoF/CbV1"}, {"rbernier_zulu": "$1$arVZSMo3$UVCjAVhyhXQmfpnYDkpIY1"}, {"rbernier": "$1$Q7urUIjO$Sm992oUd7Y4dc/QruSV7Z0"}]
