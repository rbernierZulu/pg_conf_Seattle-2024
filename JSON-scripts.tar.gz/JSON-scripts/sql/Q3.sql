-- QUERY 3:
select myrecord -> 'last_name' as "last name" from document limit 1;

 --last name
-------------
 --"bernier"
