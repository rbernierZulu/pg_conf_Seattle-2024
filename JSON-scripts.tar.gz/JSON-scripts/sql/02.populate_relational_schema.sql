\set ON_ERROR_STOP on

BEGIN;
-- 1
insert into identity(first_name,last_name,ss)
    values ('robert','bernier',123456789) returning id_identity;

-- 1
insert into address (id_identity, street_address, city, zip)
    values (1,'123 my address','my city','12345') returning id_address;

-- 1
insert into contact_info (id_identity, contact_type, contact_details)
    values (1, 'email','robert.bernier@percona.com') returning id_contact;

insert into contact_info (id_identity, contact_type, contact_details)
    values (1, 'skype','rbernier_zulu') returning id_contact;

insert into contact_info (id_identity, contact_type, contact_details)
    values (1, 'slack','rbernier') returning id_contact;

-- 1,
insert into security (id_contact, username, password)
    values (1,'user1','mypassword') returning id_security, password;

insert into security (id_contact, username, password)
    values (2,'user2','mypassword') returning id_security, password;

insert into security (id_contact, username, password)
    values (3,'user3','mypassword') returning id_security, password;

-- 2
insert into identity(first_name,last_name,ss)
    values ('conrad','black',234567891) returning id_identity;

-- 2
insert into address (id_identity, street_address, city, zip)
    values (2,'1313 mocking bird lane','smallville','23451') returning id_address;

-- 2
insert into contact_info (id_identity, contact_type, contact_details)
    values (2, 'email','user1') returning id_contact;

insert into contact_info (id_identity, contact_type, contact_details)
    values (2, 'skype','user2') returning id_contact;

COMMIT;


ANALYZE;


/* EXAMPLE: PASSWORD VALIDATION

select  password as "hashed password",
        password = crypt('mypassword', password) as authenticated
from security;

          hashed password           | authenticated
------------------------------------+---------------
 $1$yZePO7Vc$3tjqlkxTLjW9dj90vA1II. | t
 $1$m1u32mI1$pR7jYDCuRuc2LRVHAUW4.. | t
 $1$tQZrQUOi$jYWhZTa4xtA5cTBDDQ4H2. | t

*/
