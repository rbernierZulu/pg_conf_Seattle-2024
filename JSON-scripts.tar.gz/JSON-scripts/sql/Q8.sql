-- QUERY 8:
select (myrecord -> 'username_password' ->> 0)::json -> 'robert.bernier' as "my password" from document limit 1;

             my password
--------------------------------------
 "$1$AKXaaSQM$0029cNu0PHb/7UdoF/CbV1"
