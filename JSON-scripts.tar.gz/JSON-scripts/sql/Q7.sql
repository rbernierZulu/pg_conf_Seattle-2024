-- QUERY 7:
select myrecord -> 'username_password' ->> 2  as "username/password" from document  limit 1;

/*
                username/password
----------------------------------------------------
 {"rbernier": "$1$Q7urUIjO$Sm992oUd7Y4dc/QruSV7Z0"}
*/
