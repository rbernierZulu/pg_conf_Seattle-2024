-- QUERY 1:
select myrecord from document;

{"ss": "123456789", "zip": "12345", "city": "my city", "last_name": "bernier", "first_name": "robert", "id_identity": 1, "street_address": "123 my address", "username_password": [{"robert.bernier": "$1$LZoB/slh$W.stf.vWGrR7/diNJ/UeU1"}, {"rbernier_zulu": "$1$uGnN/7tV$FiFEm5POZKIlYnGAjNutg0"}, {"rbernier": "$1$MPRrHGpH$dqeVGlSAl2cT2CS44MTUa0"}, {"conrad.black": "$1$6uDGVVu9$qIKVZht3EYjdjIIKT1YXO0"}, {"cblack_literary": "$1$dibFFjBx$23/xMXavCVc0IscDPMO0f0"}]}
