-- QUERY 6:
 select myrecord -> 'username_password' ->> 1  as "username/password" from document  limit 1;

/*
                    username/password
---------------------------------------------------------
 {"rbernier_zulu": "$1$arVZSMo3$UVCjAVhyhXQmfpnYDkpIY1"}
*/
