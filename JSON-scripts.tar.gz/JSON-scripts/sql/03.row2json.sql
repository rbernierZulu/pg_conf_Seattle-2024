--===========================================================
--
-- BUILDING THE DOCUMENT
--
-- Putting It All Together
--
with
    a as (select  id_identity,
                  username,
                  password
            from security
            join contact_info using (id_contact)
            join identity using (id_identity)),

    b as (select json_agg(json_build_object(username,password)) from a),

    c as (select json_build_object('username_password',json_agg) as charlie from b),

    d as (select json_build_object (
            'id_identity',  id_identity,
            'first_name',   first_name,
            'last_name',    last_name,
            'ss',           ss,
            'street_address',street_address,
            'city',         city,
            'zip',          zip
        ) as delta from identity
          join address using (id_identity))
insert into document(myrecord)
    select delta::jsonb || charlie::jsonb from c,d;

