\o myrecord.json
select jsonb_pretty(myrecord::jsonb) from document;
\o


select myrecord from document;

{"ss": "123456789", "zip": "12345", "city": "my city", "last_name": "bernier", "first_name": "robert", "id_identity": 1, "street_address": "123 my address", "username_password": [{"robert.bernier": "$1$LZoB/slh$W.stf.vWGrR7/diNJ/UeU1"}, {"rbernier_zulu": "$1$uGnN/7tV$FiFEm5POZKIlYnGAjNutg0"}, {"rbernier": "$1$MPRrHGpH$dqeVGlSAl2cT2CS44MTUa0"}, {"conrad.black": "$1$6uDGVVu9$qIKVZht3EYjdjIIKT1YXO0"}, {"cblack_literary": "$1$dibFFjBx$23/xMXavCVc0IscDPMO0f0"}]}

select myrecord -> 'first_name' as "first name" from document limit 1;

 first name
------------
 "robert"


select myrecord -> 'last_name' as "last name" from document limit 1;

 last name
-----------
 "bernier"


select myrecord -> 'username_password' as "username/passswords" from document limit 1;
--------------------------------------------------------
[{"robert.bernier": "$1$AKXaaSQM$0029cNu0PHb/7UdoF/CbV1"}, {"rbernier_zulu": "$1$arVZSMo3$UVCjAVhyhXQmfpnYDkpIY1"}, {"rbernier": "$1$Q7urUIjO$Sm992oUd7Y4dc/QruSV7Z0"}]

select myrecord -> 'username_password' ->> 0  as "username/password" from document  limit 1;

                    username/password
----------------------------------------------------------
 {"robert.bernier": "$1$AKXaaSQM$0029cNu0PHb/7UdoF/CbV1"}


select myrecord -> 'username_password' ->> 1  as "username/password" from document  limit 1;

                    username/password
---------------------------------------------------------
 {"rbernier_zulu": "$1$arVZSMo3$UVCjAVhyhXQmfpnYDkpIY1"}

select myrecord -> 'username_password' ->> 2  as "username/password" from document  limit 1;

                username/password
----------------------------------------------------
 {"rbernier": "$1$Q7urUIjO$Sm992oUd7Y4dc/QruSV7Z0"}


select (myrecord -> 'username_password' ->> 0)::json -> 'robert.bernier' as "my password" from document limit 1;

             my password
--------------------------------------
 "$1$AKXaaSQM$0029cNu0PHb/7UdoF/CbV1"


--======================================================

select myrecord -> 'first_name' as "first name",
       myrecord -> 'last_name' as "last name",
       myrecord -> 'street_address' as "street address",
       myrecord -> 'city' as "city",
       myrecord -> 'zip' as "zip"
from document;

 first name | last name |      street address      |     city     |   zip
------------+-----------+--------------------------+--------------+---------
 "robert"   | "bernier" | "123 my address"         | "my city"    | "12345"
 "conrad"   | "black"   | "1313 mocking bird lane" | "smallville" | "23451"



select myrecord -> 'first_name' as "first name",
       myrecord -> 'last_name' as "last name",
       myrecord -> 'street_address' as "street address",
       myrecord -> 'city' as "city",
       myrecord -> 'zip' as "zip"
from document
where
    myrecord ->> 'first_name' = 'conrad'
and myrecord ->> 'last_name' = 'black';

 first name | last name |      street address      |     city     |   zip
------------+-----------+--------------------------+--------------+---------
 "conrad"   | "black"   | "1313 mocking bird lane" | "smallville" | "23451"

