-- QUERY 2:
select myrecord -> 'first_name' as "first name" from document limit 1;

 --first name
--------------
 --"robert"
