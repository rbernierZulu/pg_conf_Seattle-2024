-- QUERY 5:
select myrecord -> 'username_password' ->> 0  as "username/password" from document  limit 1;

                    username/password
----------------------------------------------------------
 {"robert.bernier": "$1$AKXaaSQM$0029cNu0PHb/7UdoF/CbV1"}
